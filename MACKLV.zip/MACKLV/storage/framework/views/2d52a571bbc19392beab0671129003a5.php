

<?php $__env->startPush('title'); ?>

<title>Product Detail</title>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-light p-5">
	<h1 class="text-center"> <i class="fa-solid fa-layer-group"></i> Product Detail</h1>	
</div>


<section class="my-5">
	<div class="container">
			<div class="row">
				<div class="col-lg-4">
				  <img src="<?php echo e(asset('assets/images/products/1.jpg')); ?>" class="rounded img-fluid">
				</div>
			

			<div class="col-lg-8">
				<div>
					<h5>RS 499.00</h5>
					<div>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star"></span>
						<h6>2 Customers Ratings</h6>
					</div>
					<p>It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.</p>
					<div>
						<a class="btn theme-green-btn text-light rounded-pill me-1">Add to cart</a>
						<a class="btn theme-orange-btn text-light rounded-pill">Buy Now</a>
			
					</div>
				</div>
				</div>

				<div class="my-4">
					<h4>Product Description</h4>
					<p>It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.It is a stablished fact that a reader will be distracted by the readable content of a page when looking at this layout.</p>
				</div>
				<div>
					<!-- Related Product -->
					<section class="my-5">
	<div class="container">

		<div class="d-flex">
		  <div class="flex-grow-1"><h4>Related Products</h4></div>
		  <div><a href="#" class="btn btn-sm theme-orange-btn text-light">View All</a></div>
		</div>

		<div class="row theme-product">
			
			<div class="col-lg-3">
				<div class="card">
				  <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/images/1.jpg')); ?>" class="card-img-top" alt="..."></a>
				  <div class="card-body">
				    <h6 class="card-title text-center"><a href="#" class="text-dark text-decoration-none">IIT Roorkee</a></h6>
				    <h5 class="card-title text-center">Indian institute</h5>
				  </div>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="card">
				  <a href="#"><img src="<?php echo e(asset('assets/images/products/1.jpg')); ?>" class="card-img-top" alt="..."></a>
				  <div class="card-body">
				    <h6 class="card-title text-center"><a href="#" class="text-dark text-decoration-none">IIT Roorkee</a></h6>
				    <h5 class="card-title text-center">Indian institute</h5>
				  </div>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="card">
				  <a href="#"><img src="<?php echo e(asset('assets/images/products/1.jpg')); ?>" class="card-img-top" alt="..."></a>
				  <div class="card-body">
				    <h6 class="card-title text-center"><a href="#" class="text-dark text-decoration-none">IIT Roorkee</a></h6>
				    <h5 class="card-title text-center">Indian institute</h5>
				  </div>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="card">
				  <a href="#"><img src="<?php echo e(asset('assets/images/products/1.jpg')); ?>" class="card-img-top" alt="..."></a>
				  <div class="card-body">
				    <h6 class="card-title text-center"><a href="#" class="text-dark text-decoration-none">IIT Roorkee</a></h6>
				    <h5 class="card-title text-center">Indian institute</h5>
				  </div>
				</div>
			</div>

		</div>

	</div>

</section>

</div><hr>

<!-- Review -->
<section>
	<h2>02 Reviews</h2>
	<div class="row mt-4">
		<div class="col-lg-1">
			<img src="<?php echo e(asset('assets/images/products/1.jpg')); ?>" class="rounded-circle img-fluid">
		</div>
		<div class="col-lg-11">
			<div>
				<h4>John Doe</h4>
				<div>
					<div class="d-flex">
						<div class="flex-grow-1"><h6>13/Nov/2025</h6></div>
						<div>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
						</div>
						
					</div>
				</div>
				<p> This is IIT Roorkee and its first civil engineering college of india, named James Thomasan College</p>
				<div>
					<a class="btn theme-orange-btn btn-sm text-light rounded-pill">Reply</a>
				</div>
			</div>
			
		</div>

		<div class="col-lg-1 mt-4">
			<img src="<?php echo e(asset('assets/images/products/1.jpg')); ?>" class="rounded-circle img-fluid">
		</div>
		<div class="col-lg-11 mt-4">
			<div>
				<h4>Mack</h4>
				<div>
					<div class="d-flex">
						<div class="flex-grow-1"><h6>13/Nov/2025</h6></div>
						<div>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
						</div>
						
					</div>
				</div>
				<p> This is IIT Roorkee and its first civil engineering college of india, named James Thomasan College</p>
				<div>
					<a class="btn theme-orange-btn btn-sm text-light rounded-pill">Reply</a>
				</div>
			</div>
			
		</div>
		
	</div>
	
</section>

<!-- Add a Review -->

<section>
	<div class="container my-4">
		<h4>Add a Review</h4>
		<div class="row">
			<div class="col-lg-12">
				<form>
					<div id="emailHelp" class="form-text">Rate this product?
							<span class="fa fa-star"></span>
							<span class="fa fa-star"></span>
							<span class="fa fa-star"></span>
							<span class="fa fa-star"></span>
							<span class="fa fa-star"></span>
						</div>
					<div class="row my-3">
					<div class="col-lg-6 mb-3">
						<input type="text" class="form-control form-control-lg" placeholder="Your Name">
					</div>

					<div class="col-lg-6 mb-3">
						<input type="email" class="form-control form-control-lg" placeholder="Your Email">
					</div>
					
					<div class="col-lg-12 mb-3">
						<textarea class="form-control form-control-lg" placeholder="Your Message" rows="3"></textarea>
					</div>

					<div>
						<a class="btn theme-orange-btn text-light rounded-pill">Post a Comment <i class="fa-solid fa-arrow-right"></i></a>	
					</div>

				</div>
				</form>
				
			</div>
			
		</div>
		
	</div>
</section>

</div></div>
	
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\MACKLV\resources\views/product-detail.blade.php ENDPATH**/ ?>