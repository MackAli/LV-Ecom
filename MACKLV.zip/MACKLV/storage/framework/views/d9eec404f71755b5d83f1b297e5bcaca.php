
<footer class="text-center p-3 theme-footer text-light">
	© 2025 Mack Ali. All Right Reserved. Design and Developed.
</footer>
 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\wamp64\www\MACKLV\resources\views/layouts/footer.blade.php ENDPATH**/ ?>